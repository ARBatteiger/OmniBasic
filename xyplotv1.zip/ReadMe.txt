Simple x,y plot control, written by Adam Jackson, August 2003.
This control is free for use and modification by anyone.  I would prefer it if modifications/improvements that are made could be sent to adamjjackson@hotmail.com, just so that I can learn.  In the unlikey event that anyone makes any money from this, I wouldn't say no to a free sample of the programme that it was in!
This control can plot integer vaules of y against x, of vice-versa.  Any number of pens and points can be used, and pens and points can be added or removed at any time.  The pens and the 'paper' can be drawn in any colour.


====================
To use the control:
1. Move the xyPlot.inc file to the masm32\include directory.
2. Move the xyPlot.lib file to the masm32\lib directory.
    [Or run the Make.bat file.]
3. Include the above in your program, for example:
	include \masm32\include\xyPlot.inc              ; Add the Include and Lib.
	includelib \masm32\lib\xyPlot.lib
4. After registering your windows class include the line:
	CreatexyPlotClass hInstance			      ; Register xyPlot class.
	NOTE: The fuction using this macro must have the following declaired as a local variable 'LOCAL wc	:WNDCLASSEX'
5. Create an instance of the control:
	;invoke xyPlot,ADDR szClassName,hWin,x,y,width,height,unique_child_identifier
	invoke xyPlot,ADDR szClassName,hWin,0,0,600,300,1001
	mov hXYPlotWnd1,eax
====================

The control can be controlled using the following custom messages:

CM_ADDPOINT equ WM_USER+100		;Used to add a point to the plot. wParam=NULL,lParam=lpAddData
lpData is a pointer to the following structure which is filled by the program:
ADDDATA STRUCT
	PenID   dd ?        ; Which pen.
	Index   dd ?        ; E.g. 3. This will insert the data after the second point, third point becomes the fourth, etc.
	xVal    dd ?        ; x value.
	yVal    dd ?        ; y value.
ADDDATA ENDS

CM_ADDPEN equ WM_USER+102		; Add a new pen. wParam=PenID,lParam=PenColour
						; Start with PenID=1, increment by 1 each time. So next pen has PenID=2.

CM_REMOVEPEN equ WM_USER+103        ; Remove a pen and associated data. wParam=PenID,lParam=NULL
						; Note, unlike data (See next), when PenID=3 is removed, PenID=4 remains PenID=4.

CM_REMOVEPOINT equ WM_USER+104      ; Remove a data point. wParam=PenID,lParam=Index - e.g. 3, this will remove the third point, the following points will cascade downwards - the fourth point will become the third, etc.

CM_SETPAPERCOLOR equ WM_USER+105    ; Set paper colour. wParam=Colour,lParam=NULL

To scale the data, CM_SCALE should be sent to the control once all data has been added, or after a manipulation of the data (such as removing a point or pen, or adding a new point or pen).
CM_SCALE equ WM_USER+101            ; Scale the data. wParam=NULL,lParam=NULL

Examples of how to use these messages can be found in the xyPlotExample.asm file.


====================
Finally, thanks to "Nan" for the excellent custom control tutorial, and to Milos for the linkedlist example.