The MButtons Control
--------------------

The control in the "MButton" directory will compile and copy into you masm include/lib dirs
by running MAKE.BAT found it that directory.  It will automatically update the include
and lib directories for its use.

Its simple to use:

1) Register the control (use:  "CreateMBClass hInstance")
2) Invoke instances     (use:  "invoke MButton, addr szTest, hWin, 0,0,125,50,HNDMENU, 1234")
			(Note: ID is the '1234' param. 					    )

 *ALSO NOTE*  If you intend to add a bitmap onto the control, you must ensure that the
 -----------     bitmpa is SQUARE (SIZE x SIZE), and that the control size is created such that:
		 Width  >= SIZE + 12
	         Height >= SIZE + 16


As well, you need to create your own POPUP menu if you wish to use the 'menu' aspect.  
You do not HAVE to do this, if not, set the HNDMENU param to NULL.

The Messages It can suport are:

 BM_SETMENU	wParam = NULL, lParm = hMenu  (Set/Change the Popup menu)
 BM_SETIMAGE	wParam = NULL, lParam = hBitmap. (The bitmap to display as an image)

 WM_SETTEXT	( Same as normal message, but limited to 28 chars! )
		( Setting this to NULL will center the IMAGE if provided)

 WM_SETFONT	( Same as normal message )


-----------------------------------------------------------------------------------------------
Masm Lib:
---------

The Masm32 library must be updated to suport this control.  I have created another lib entry
that must be added.  In the directory "MASM32", you will need to copy the "TransBit.asm" file
out into your "\MASM32\M32LIB\" directory.  Once copied, open the file "TransBit.asm", and
follow the instructions to copy the THREE entries into the "masm32.inc file", located in the 
same directory.  Once this is done, the include file updated, and TransBit is copied, run
the "MAKE.bat" file to generate a NEW MASM32.LIB and update the \include\ and \lib\ dirs.

Now your set.  You can use this for other projects as well. 
Its purpose is to copy a BITMAP to a DC while generating and applying a transparency MASK.

invoke DrawTransparentBitmap, hDC_Destination,
                              hBitmap to draw,
                              DC starting x point,
                              DC starting y point,
                              Transparent color

In usage the x,y point is where the upper right corner of the bitmap will be on the DC. The 
Transparency color can either be: 

 - Any RGB color you choose, but as a DWORD, it must not have the 32nd bit set ( 80000000h ). 

 - TBM_FIRSTPIXEL :: This will use the first pixel (0,0) in the bitmap as the transparency
		     color used. This equate is the 8000000h value. 


-----------------------------------------------------------------------------------------------
Well this is it! Enjoy
(NaN)-( http://NaN32Asm.cjb.Net )

