You must edit all three files to get this to work.  As specific information is needed about the control you wish to make.  Namely its File and Control name information.

NaN